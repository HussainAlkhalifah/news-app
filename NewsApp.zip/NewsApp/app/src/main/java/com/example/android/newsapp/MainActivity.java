package com.example.android.newsapp;

import android.app.LoaderManager;
import android.content.AsyncTaskLoader;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<ArrayList<News>> {
    private static final String NEWS_REQUEST_URL = "https://content.guardianapis.com/search?&show-tags=contributor&api-key=test";
    ArrayList<News> news = new ArrayList<News>();
    ArrayList<News> newsDef = new ArrayList<News>();

    NewsAdapter newsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_view);
        ListView newsListView = (ListView) findViewById(R.id.listview);
        newsAdapter = new NewsAdapter(MainActivity.this, news);
        newsListView.setAdapter(newsAdapter);
        LoaderManager loaderManager = getLoaderManager();
        loaderManager.initLoader(0, null, this);

        newsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                News curNews = newsAdapter.getItem(position);
                Uri newsUri = Uri.parse(curNews.getWebUrl());
                Intent websiteIntent = new Intent(Intent.ACTION_VIEW, newsUri);
                startActivity(websiteIntent);
            }
        });

    }


    @Override
    public Loader<ArrayList<News>> onCreateLoader(int i, Bundle bundle) {
        return new NewsLoader(this, NEWS_REQUEST_URL);

    }

    @Override
    public void onLoadFinished(Loader<ArrayList<News>> loader, ArrayList<News> news) {
        if (newsAdapter != null) {
            newsAdapter.clear();
        }

        if (news != null && !news.isEmpty()) {
            newsAdapter.addAll(news);
        }
        if (news == null || news.isEmpty()) {

            String title = "Title";
            String section = "Section";
            String date = "Date";
            String web = "WebUrl";
            String author = "Author";


            newsDef.add(new News(section, title, date, web, author));
            newsAdapter.addAll(newsDef);


        }

    }

    @Override
    public void onLoaderReset(Loader<ArrayList<News>> loader) {
        newsAdapter.clear();

    }

}